# EMail-System-Using-J2EE

# Mailing System:
This project deals with the Mailing System. This Mailing System project is having different modules example new user create our account from gmail it as a Sign-Up form and already existing user can logged into the Mailing System named it as a login in form.
E-mail System (or Intranet Mailing) which has been privatized and is existing in different forms like Hotmail. Free mail. Cyber mail, Mainly The project will give the easy way to create a new account with your gmail and reply, forward, delete, receive and sending mails with free of cost.

# Purpose:-
This project aims at developing a web based mail system the user to send and receive mail through send mail as (MTA) message transport and IAMP, SMTP, POP as the message delivery agent.

This exiting user is needed to authentication their identity and then they permitted to check their mail in their mailbox. Also they can send mail. Organize mail across the folder and can delete the necessary mail from mailbox. A good user interface has been provided for performing all these task easily.
