/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.User;

/**
 *
 * @author ajay
 */
public class check {

    public static void main(String[] args) {
        UserPass obj = new UserPass();
        String pass = obj.Userpass("dummy2263@gmail.com");
        System.out.println(pass);

    }
}
